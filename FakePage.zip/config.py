HEROKU = False  # NOTE 
#-> کریستال تیم
#-> سورس های برتر
#-> کد های ناب

#جوین شید و لذت ببرید.
#• @Cristal_Team

# NOTE 
if HEROKU:
    from os import environ

    API_ID = int(environ["API_ID"])
    API_HASH = environ["API_HASH"]
    SUDO_CHAT_ID = int(
        environ["SUDO_CHAT_ID"]
    ) 
    SUDOERS = list(
        int(x) for x in environ.get("SUDOERS", "").split()
    )  
    SESSION_STRING = environ["SESSION_STRING"]  
    ARQ_API_KEY = environ["ARQ_API_KEY"]

# NOTE 
if not HEROKU:
    API_ID = 7273371#ای پی ای ای دی از تلگرام بگیرید
    API_HASH = "553337e711993d5be5dd95b61781eb4b"#ای پی ای هش هم از تلگرام بگیرید اینجا بزارید
    SUDO_CHAT_ID = 1900060993
    SUDOERS = [1900060993,1219147672]#ایدی عددی ادمین ها
    ARQ_API_KEY = "SINOAY-QWAZJC-YVADAV-VIRGPF-ARQ"
# don't make changes below this line
ARQ_API = "https://thearq.tech"
#
#-> کریستال تیم
#-> سورس های برتر
#-> کد های ناب

#جوین شید و لذت ببرید.
#• @Cristal_Team
